/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.test;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.hamcrest.beans.HasProperty;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.mvc.booking.restaurant.controller.BlockController;
import com.mindtree.mvc.booking.restaurant.entities.Block;
import com.mindtree.mvc.booking.restaurant.services.BlockServices;

/**
 * @author M1057685
 *
 */
@SpringBootTest
@RunWith(MockitoJUnitRunner.Silent.class)
//@ContextConfiguration(classes = {TestContext.class, BlockController.class})
public class BlockControllerTest {
	@InjectMocks
	private BlockController blockController;
	@Mock
//	@Autowired
	private BlockServices blockServices;
	private MockMvc mockMvc;
//	Block block = new Block();

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(blockController).build();
	}

	@Test
	public void indexPage() throws Exception {
		mockMvc.perform(get("/")).andExpect(status().isOk()).andExpect(view().name("index"));
	}

	@Test
	public void blockPage() throws Exception {
//		Block block = new Block();
		mockMvc.perform(post("/viewBlockPage")).andExpect(status().isOk()).andExpect(view().name("blockPage"))
				.andExpect(forwardedUrl("blockPage"))
				.andExpect(model().attribute("block", HasProperty.hasProperty("blockId")))
				.andExpect(model().attribute("block", HasProperty.hasProperty("blockName")))
				.andExpect(model().attribute("block", HasProperty.hasProperty("restaurant")));
	}

	@Test
	public void saveBlock() throws Exception {
		Block blockObj = new Block(1, "SWAPNIL", null);
		when(blockServices.addBlocks(blockObj)).thenReturn(blockObj);
		mockMvc.perform(post("/saveBlocks")).andExpect(status().isOk()).andExpect(view().name("index"))
				.andExpect(forwardedUrl("index"));
	}
}
