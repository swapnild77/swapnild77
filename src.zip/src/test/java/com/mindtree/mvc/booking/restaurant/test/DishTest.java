/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.mindtree.mvc.booking.restaurant.entities.AscendingOrder;
import com.mindtree.mvc.booking.restaurant.entities.Block;
import com.mindtree.mvc.booking.restaurant.entities.DescendingPrice;
import com.mindtree.mvc.booking.restaurant.entities.Dishes;
import com.mindtree.mvc.booking.restaurant.entities.Restaurant;
import com.mindtree.mvc.booking.restaurant.repository.BlockRepository;
import com.mindtree.mvc.booking.restaurant.repository.DishesRepository;
import com.mindtree.mvc.booking.restaurant.repository.RestaurantRepository;
import com.mindtree.mvc.booking.restaurant.services.impl.DishServiceImpl;
import com.mindtree.mvc.booking.restaurant.services.impl.RestaurantServiceImpl;

/**
 * @author M1057685
 *
 */
@SpringBootTest
@RunWith(MockitoJUnitRunner.Silent.class)
public class DishTest {
	@InjectMocks
	private DishServiceImpl dishServiceImpl;

	@InjectMocks
	private RestaurantServiceImpl restaurantServiceImpl;

	@Mock
	private DishesRepository dishesRepository;

	@Mock
	private RestaurantRepository restaurantRepository;

	@Mock
	private BlockRepository blockRepository;

	Restaurant restaurant = new Restaurant();
	DescendingPrice decendingPrice = new DescendingPrice();
	AscendingOrder ascendingOrder=new AscendingOrder();
	Dishes dishes = new Dishes();
	Block block = new Block();

	@Before
	public void setDishRepo() {
		MockitoAnnotations.initMocks(this);
		List<Dishes> dishList = new ArrayList<Dishes>();
		dishList.add(new Dishes(1, "CHICKEN", 100, "NON-VEG", restaurant));
		dishList.add(new Dishes(2, "CHICKEN BIRIYANI", 200, "NON-VEG", restaurant));
		dishList.add(new Dishes(3, "CHICKEN TIKKA", 300, "NON-VEG", restaurant));
		restaurant.setDishes(dishList);
		List<Dishes> getDishFromRestaurant = restaurant.getDishes();
		when(restaurantRepository.findById(1)).thenReturn(Optional.of(restaurant));
		when(dishesRepository.findAll()).thenReturn(getDishFromRestaurant);
	}

	@Test
	public void getDishInDecending() {
		List<Dishes> getDishesFromRestaurant = restaurant.getDishes();
		assertEquals(getDishesFromRestaurant, dishServiceImpl.getDishInDecending(restaurant));
	}

	@Before
	public void setDishRepoAgain() {
		MockitoAnnotations.initMocks(this);
		List<Dishes> dishList = new ArrayList<Dishes>();
		dishList.add(new Dishes(1, "CHICKEN", 100, "NON-VEG", restaurant));
		dishList.add(new Dishes(2, "CHICKEN BIRIYANI", 200, "NON-VEG", restaurant));
		dishList.add(new Dishes(3, "CHICKEN TIKKA", 300, "NON-VEG", restaurant));
		restaurant.setDishes(dishList);
		List<Dishes> getDishFromRestaurant = restaurant.getDishes();
		when(restaurantRepository.findById(1)).thenReturn(Optional.of(restaurant));
		when(dishesRepository.findAll()).thenReturn(getDishFromRestaurant);
	}

	@Test
	public void getDishInAscending() {
		List<Dishes> getDishesFromRestaurant = restaurant.getDishes();
		assertEquals(getDishesFromRestaurant, dishServiceImpl.getDishInAscending(restaurant));
	}

	@Before
	public void setUpRestaurantRepoNow() {
		MockitoAnnotations.initMocks(this);
		List<Restaurant> restaurantList = new ArrayList<Restaurant>();
		restaurantList.add(new Restaurant(1, "XXXAA", "CCC", 3.5, null, null));
		restaurantList.add(new Restaurant(2, "XXXYYYAA", "CCC", 3.9, null, null));
		when(restaurantRepository.findAll()).thenReturn(restaurantList);
	}

	@Test
	public void findAllRestaurantInDish() {
		List<Restaurant> restaurantList = restaurantRepository.findAll();
		assertEquals(restaurantList, dishServiceImpl.restaurantList());
	}
}
