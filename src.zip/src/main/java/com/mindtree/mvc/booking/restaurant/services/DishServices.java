/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.mvc.booking.restaurant.entities.Dishes;
import com.mindtree.mvc.booking.restaurant.entities.Restaurant;

/**
 * @author M1057685
 *
 */
@Service
public interface DishServices {
	/**
	 * @return
	 */
	public List<Restaurant> restaurantList();

	/**
	 * @param dishes
	 * @param restaurantObj
	 */
	public void saveDishes(Dishes dishes, Restaurant restaurantObj);

	/**
	 * @param restaurant
	 * @return
	 */
	public List<Dishes> getDishInAscending(Restaurant restaurant);

	/**
	 * @param restaurant
	 * @return
	 */
	public List<Dishes> getDishInDecending(Restaurant restaurant);
}
