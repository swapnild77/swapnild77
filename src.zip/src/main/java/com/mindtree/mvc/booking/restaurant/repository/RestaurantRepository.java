package com.mindtree.mvc.booking.restaurant.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.mvc.booking.restaurant.entities.Restaurant;

/**
 * @author M1057685
 *
 */
public interface RestaurantRepository extends JpaRepository<Restaurant, Integer>{
	/**
	 * @param restaurantType
	 * @return
	 */
	public List<Restaurant> getAllByRestaurantType(String restaurantType);
}
