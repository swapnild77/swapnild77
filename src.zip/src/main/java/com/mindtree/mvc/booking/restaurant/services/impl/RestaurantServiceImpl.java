/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.services.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.mvc.booking.restaurant.entities.Block;
import com.mindtree.mvc.booking.restaurant.entities.Restaurant;
import com.mindtree.mvc.booking.restaurant.repository.BlockRepository;
import com.mindtree.mvc.booking.restaurant.repository.RestaurantRepository;
import com.mindtree.mvc.booking.restaurant.services.RestaurantService;

/**
 * @author M1057685
 *
 */
@Service
public class RestaurantServiceImpl implements RestaurantService {
	@Autowired
	private BlockRepository blockRepository;
	@Autowired
	private RestaurantRepository restaurantRepository;

	@Override
	public List<Block> getBlockName() {
		List<Block> block = blockRepository.findAll();
		return block;
	}

	@Override
	public Restaurant saveRestaurants(Block blockObj, Restaurant restaurant) {
		Block block = blockRepository.findById(blockObj.getBlockId()).orElse(blockObj);
		restaurant.setBlock(block);
		List<Restaurant> restaurantList = new ArrayList<Restaurant>();
		restaurantList.add(restaurant);
		Set<Restaurant> convertToSet = new HashSet<Restaurant>();
		block.setRestaurant(convertToSet);
		restaurantRepository.save(restaurant);
		return restaurant;
	}

	@Override
	public List<Restaurant> getAllRestaurant() {
		List<Restaurant> getAllRestaurant = restaurantRepository.findAll();
		return getAllRestaurant;
	}

	@Override
	public List<Restaurant> getAllRestaurantBtType(Restaurant restaurant) {
		List<Restaurant> restaurantList = restaurantRepository.findAll();
		List<Restaurant> restaurantByType = restaurantList.stream()
				.filter(t -> t.getRestaurantType().equalsIgnoreCase(restaurant.getRestaurantType()))
				.collect(Collectors.toList());
		return restaurantByType;
	}

	@Override
	public List<Restaurant> getDetailsByBlockName(Block block) {
		Block temp=blockRepository.findById(block.getBlockId()).orElse(block);
		Set<Restaurant> getDetails=temp.getRestaurant();
		List<Restaurant> details=new ArrayList<Restaurant>(getDetails);
		return details;
	}
}
