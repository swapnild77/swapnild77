/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.mvc.booking.restaurant.entities.Block;
import com.mindtree.mvc.booking.restaurant.repository.BlockRepository;
import com.mindtree.mvc.booking.restaurant.services.BlockServices;

/**
 * @author M1057685
 *
 */
@Service
public class BlockServiceImpl implements BlockServices{
@Autowired
private BlockRepository blockRepository;
	@Override
	public Block addBlocks(Block block) {
		return blockRepository.save(block);
	}

}
