/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.mvc.booking.restaurant.entities.Dishes;

/**
 * @author M1057685
 *
 */
public interface DishesRepository extends JpaRepository<Dishes, Integer>{

}
