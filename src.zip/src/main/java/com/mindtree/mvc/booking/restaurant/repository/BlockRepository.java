/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.mvc.booking.restaurant.entities.Block;

/**
 * @author M1057685
 *
 */
public interface BlockRepository extends JpaRepository<Block, Integer>{
//	/**
//	 * @param blockName
//	 * @return
//	 */
//	public Block findByBlockName(String blockName);
}
