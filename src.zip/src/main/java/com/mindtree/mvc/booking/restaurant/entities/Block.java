/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

/**
 * @author M1057685
 *
 */
@Entity
public class Block {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int blockId;
	@NotNull
	private String blockName;
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "block")
	private Set<Restaurant> restaurant;

	/**
	 * @param blockId    Integer
	 * @param blockName  String
	 * @param restaurant Restaurant
	 */
	public Block(int blockId, @NotNull String blockName, Set<Restaurant> restaurant) {
		this.blockId = blockId;
		this.blockName = blockName;
		this.restaurant = restaurant;
	}

	/**	
	 * 
	 */
	public Block() {
	}

	/**
	 * @return the blockId Integer
	 */
	public int getBlockId() {
		return blockId;
	}

	/**
	 * @param blockId the blockId Integer to set
	 */
	public void setBlockId(int blockId) {
		this.blockId = blockId;
	}

	/**
	 * @return the blockName String
	 */
	public String getBlockName() {
		return blockName;
	}

	/**
	 * @param blockName the blockName String to set
	 */
	public void setBlockName(String blockName) {
		this.blockName = blockName;
	}

	/**
	 * @return the restaurant Restaurant
	 */
	public Set<Restaurant> getRestaurant() {
		return restaurant;
	}

	/**
	 * @param restaurant the restaurant Restaurant to set
	 */
	public void setRestaurant(Set<Restaurant> restaurant) {
		this.restaurant = restaurant;
	}
}
