package com.mindtree.mvc.booking.restaurant.services;

import org.springframework.stereotype.Service;

import com.mindtree.mvc.booking.restaurant.entities.Block;
@Service
public interface BlockServices {
	/**
	 * @param block
	 * @return
	 */
	public Block addBlocks(Block block);
}
