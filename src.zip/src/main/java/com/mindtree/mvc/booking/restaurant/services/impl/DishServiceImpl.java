/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.services.impl;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.mvc.booking.restaurant.entities.AscendingOrder;
import com.mindtree.mvc.booking.restaurant.entities.DescendingPrice;
import com.mindtree.mvc.booking.restaurant.entities.Dishes;
import com.mindtree.mvc.booking.restaurant.entities.Restaurant;
import com.mindtree.mvc.booking.restaurant.repository.DishesRepository;
import com.mindtree.mvc.booking.restaurant.repository.RestaurantRepository;
import com.mindtree.mvc.booking.restaurant.services.DishServices;

/**
 * @author M1057685
 *
 */
@Service
public class DishServiceImpl implements DishServices {
	@Autowired
	private RestaurantRepository restaurantRepository;
	@Autowired
	private DishesRepository dishesRepository;

	@Override
	public List<Restaurant> restaurantList() {
		List<Restaurant> restaurantList = restaurantRepository.findAll();
		return restaurantList;
	}

	@Override
	public void saveDishes(Dishes dishes, Restaurant restaurantObj) {
		Restaurant restaurant = restaurantRepository.findById(restaurantObj.getRestaurantId()).orElse(restaurantObj);
		if ((restaurant.getRestauranRate() > 4.5) && (restaurant.getRestauranRate() < 5)) {
			dishes.setDishPrice(dishes.getDishPrice() - (0.1d * dishes.getDishPrice()));
			dishes.setRestaurant(restaurant);
			List<Dishes> getAllDishes = restaurant.getDishes();
			getAllDishes.add(dishes);
			restaurant.setDishes(getAllDishes);
			dishesRepository.save(dishes);
		} else if ((restaurant.getRestauranRate() > 3.5) && (restaurant.getRestauranRate() < 4.5)) {
			dishes.setDishPrice(dishes.getDishPrice() - (0.05d * dishes.getDishPrice()));
			dishes.setRestaurant(restaurant);
			List<Dishes> getAllDishes = restaurant.getDishes();
			getAllDishes.add(dishes);
			restaurant.setDishes(getAllDishes);
			dishesRepository.save(dishes);
		} else if ((restaurant.getRestauranRate() > 2.5) && (restaurant.getRestauranRate() < 3.5)) {
			dishes.setDishPrice(dishes.getDishPrice() - (0.02d * dishes.getDishPrice()));
			dishes.setRestaurant(restaurant);
			List<Dishes> getAllDishes = restaurant.getDishes();
			getAllDishes.add(dishes);
			restaurant.setDishes(getAllDishes);
			dishesRepository.save(dishes);
		} else {
			dishes.setRestaurant(restaurant);
			List<Dishes> getAllDishes = restaurant.getDishes();
			getAllDishes.add(dishes);
			restaurant.setDishes(getAllDishes);
			dishesRepository.save(dishes);
		}
	}

	@Override
	public List<Dishes> getDishInAscending(Restaurant restaurant) {
		Restaurant temp = restaurantRepository.findById(restaurant.getRestaurantId()).orElse(restaurant);
		List<Dishes> getDishes = temp.getDishes();
		Collections.sort(getDishes, new AscendingOrder());
		return getDishes;
	}

	@Override
	public List<Dishes> getDishInDecending(Restaurant restaurant) {
		Restaurant temp = restaurantRepository.findById(restaurant.getRestaurantId()).orElse(restaurant);
		List<Dishes> getDishes = temp.getDishes();
		Collections.sort(getDishes, new DescendingPrice());
		return getDishes;
	}

}
