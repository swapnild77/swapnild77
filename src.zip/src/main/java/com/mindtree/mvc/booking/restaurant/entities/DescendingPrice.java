/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.entities;

import java.util.Comparator;

/**
 * @author M1057685
 *
 */
public class DescendingPrice implements Comparator<Dishes>{

	@Override
	public int compare(Dishes o1, Dishes o2) {
		return (int) (o2.getDishPrice()-o1.getDishPrice());
	}

}
