package com.mindtree.mvc.booking.restaurant.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.mvc.booking.restaurant.entities.Block;
import com.mindtree.mvc.booking.restaurant.entities.Restaurant;

/**
 * @author M1057685
 *
 */
@Service
public interface RestaurantService {
/**
 * @return
 */
public List<Block> getBlockName();

/**
 * @param blockObj
 * @param restaurant
 * @return 
 */
public Restaurant saveRestaurants(Block blockObj, Restaurant restaurant);
/**
 * @return
 */
public List<Restaurant> getAllRestaurant();

/**
 * @param restaurant
 * @return
 */
public List<Restaurant> getAllRestaurantBtType(Restaurant restaurant);

/**
 * @param block
 * @return
 */
public List<Restaurant> getDetailsByBlockName(Block block);
}
