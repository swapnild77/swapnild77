/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mindtree.mvc.booking.restaurant.entities.Block;
import com.mindtree.mvc.booking.restaurant.entities.Restaurant;
import com.mindtree.mvc.booking.restaurant.services.RestaurantService;

/**
 * @author M1057685
 *
 */
@Controller
public class RestaurantController {
	Block blockTemp;
	@Autowired
	private RestaurantService restaurantService;

	@RequestMapping(value = "/goRestaurantPage")
	public String displayBlockName(Model model) {
		Restaurant restaurant=new Restaurant();
		model.addAttribute("restaurant", restaurant);
		Block block = new Block();
		List<Block> blockNameList = restaurantService.getBlockName();
		model.addAttribute("blockNameList", blockNameList);
		model.addAttribute("block", block);
//		List<Restaurant> restaurantNameList=restaurantService.getAllRestaurant();
//		model.addAttribute("restaurantNameList", restaurantNameList);
		return "restaurantPage";
	}

	@RequestMapping(value = "/addRestaurantDetails")
	public String addRestaurantDetails(Model model, @ModelAttribute(value = "block") Block block) {
		Restaurant restaurant = new Restaurant();
		model.addAttribute("restaurant", restaurant);
		blockTemp = block;
		return "restaurantDetailPage";
	}

	@RequestMapping(value = "saveRestaurant")
	public String saveRestaurant(@ModelAttribute(value = "restaurant") Restaurant restaurant, Block BlockObj) {
		BlockObj = blockTemp;
		restaurantService.saveRestaurants(BlockObj, restaurant);
		return "redirect:/";
	}
	
	@RequestMapping(value = "/viewRestaurantDetailsWRTType")
	public String restaurantDetails(@ModelAttribute(value = "restaurant") Restaurant restaurant,Model model)
	{
		System.out.println(restaurant.getRestaurantType());
		List<Restaurant> getAllRestaurantDetails=restaurantService.getAllRestaurantBtType(restaurant);
		model.addAttribute("getAllRestaurantDetails", getAllRestaurantDetails);
		return "displayRestaurantPage";
	}
	
	@RequestMapping(value = "/history")
	public String history(Model model)
	{
		@SuppressWarnings("unused")
		Block block = new Block();
		List<Block> blockNameList = restaurantService.getBlockName();
		model.addAttribute("blockNameList", blockNameList);
		return "historyPage";
	}
	
	@RequestMapping(value = "/particularBlockName")
	public String blockDetails(@ModelAttribute(value = "block") Block block,Model model)
	{
		List<Restaurant> getAllRestaurant=restaurantService.getDetailsByBlockName(block);
		model.addAttribute("getAllRestaurant", getAllRestaurant);
		return "detailsPage";
	}
}
