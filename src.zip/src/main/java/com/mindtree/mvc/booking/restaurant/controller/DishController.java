/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mindtree.mvc.booking.restaurant.entities.Dishes;
import com.mindtree.mvc.booking.restaurant.entities.Restaurant;
import com.mindtree.mvc.booking.restaurant.services.DishServices;

/**
 * @author M1057685
 *
 */
@Controller
public class DishController {
	Restaurant restaurantTemp;
	@Autowired
	private DishServices dishServices;

	@RequestMapping(value = "/dishPage")
	public String dishPage(Model model) {
		Restaurant restaurant = new Restaurant();
		model.addAttribute("restaurant", restaurant);
		List<Restaurant> restaurantNameList = dishServices.restaurantList();
		model.addAttribute("restaurantNameList", restaurantNameList);
		return "dishPage";
	}

	@RequestMapping(value = "/addDishDetails")
	public String saveDishes(@ModelAttribute(value = "restaurant") Restaurant restaurant, Model model) {
		restaurantTemp = restaurant;
		Dishes dishes = new Dishes();
		model.addAttribute("dishes", dishes);
		return "dishDetailPage";
	}

	@RequestMapping(value = "/saveDish")
	public String saveDish(@ModelAttribute(value = "dishes") Dishes dishes, Restaurant restaurantObj) {
		restaurantObj = restaurantTemp;
		dishServices.saveDishes(dishes, restaurantObj);
		return "redirect:/";
	}
	
	@RequestMapping(value = "/displayInAscending")
	public String displayInAscending(Model model)
	{
		Restaurant restaurant=new Restaurant();
		model.addAttribute("restaurant", restaurant);
		List<Restaurant> restaurantList=dishServices.restaurantList();
		model.addAttribute("restaurantList",restaurantList );
		return "dishDetails";
	}
	
	@RequestMapping(value = "/getRestaurantNameForDishes")
	public String displayAscending(@ModelAttribute(value = "restaurant")Restaurant restaurant,Model model)
	{
		List<Dishes> dishDetailsList=dishServices.getDishInAscending(restaurant);
		model.addAttribute("dishDetailsList", dishDetailsList);
		return "dishDetailsPage";
	}
	
	@RequestMapping(value = "/displayInDecending")
	public String displayDecending(Model model)
	{
		Restaurant restaurant=new Restaurant();
		model.addAttribute("restaurant", restaurant);
		List<Restaurant> restaurantList=dishServices.restaurantList();
		model.addAttribute("restaurantList",restaurantList );
		return "dishDetails1";
	}
	
	@RequestMapping(value = "/getRestaurantNameForDishesDec")
	public String displayDecending(@ModelAttribute(value = "restaurant")Restaurant restaurant,Model model)
	{
		List<Dishes> dishDetailsList=dishServices.getDishInDecending(restaurant);
		model.addAttribute("dishDetailsList", dishDetailsList);
		return "descendingOder";
	}
}
