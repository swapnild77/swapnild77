/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.entities;

import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author M1057685
 *
 */
@Entity
public class Restaurant {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int restaurantId;
	@NotNull
	private String restaurantName;
	@NotNull
	private String restaurantType;
	@NotNull
	private double restauranRate;
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private Block block;
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "restaurant")
	private List<Dishes> dishes;

	/**
	 * @param restaurantId   Integer
	 * @param restaurantName String
	 * @param restaurantType String
	 * @param restauranRate  double
	 * @param block          Block
	 * @param dishes         Dishes
	 */
	public Restaurant(int restaurantId, @NotNull String restaurantName, @NotNull String restaurantType,
			@NotNull double restauranRate, Block block, List<Dishes> dishes) {
		this.restaurantId = restaurantId;
		this.restaurantName = restaurantName;
		this.restaurantType = restaurantType;
		this.restauranRate = restauranRate;
		this.block = block;
		this.dishes = dishes;
	}

	/**
	 * 
	 */
	public Restaurant() {
	}

	/**
	 * @return the restaurantId Integer
	 */
	public int getRestaurantId() {
		return restaurantId;
	}

	/**
	 * @param restaurantId the restaurantId Integer to set
	 */
	public void setRestaurantId(int restaurantId) {
		this.restaurantId = restaurantId;
	}

	/**
	 * @return the restaurantName String
	 */
	public String getRestaurantName() {
		return restaurantName;
	}

	/**
	 * @param restaurantName the restaurantName String to set
	 */
	public void setRestaurantName(String restaurantName) {
		this.restaurantName = restaurantName;
	}

	/**
	 * @return the restaurantType String
	 */
	public String getRestaurantType() {
		return restaurantType;
	}

	/**
	 * @param restaurantType the restaurantType String to set
	 */
	public void setRestaurantType(String restaurantType) {
		this.restaurantType = restaurantType;
	}

	/**
	 * @return the restauranRate double
	 */
	public double getRestauranRate() {
		return restauranRate;
	}

	/**
	 * @param restauranRate the restauranRate double to set
	 */
	public void setRestauranRate(double restauranRate) {
		this.restauranRate = restauranRate;
	}

	/**
	 * @return the block Block
	 */
	public Block getBlock() {
		return block;
	}

	/**
	 * @param block the block Block to set
	 */
	public void setBlock(Block block) {
		this.block = block;
	}

	/**
	 * @return the dishes Dishes
	 */
	public List<Dishes> getDishes() {
		return dishes;
	}

	/**
	 * @param dishes the dishes Dishes to set
	 */
	public void setDishes(List<Dishes> dishes) {
		this.dishes = dishes;
	}

	@Override
	public int hashCode() {
		return Objects.hash(restaurantName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Restaurant)) {
			return false;
		}
		Restaurant other = (Restaurant) obj;
		return Objects.equals(restaurantName, other.restaurantName);
	}
}
