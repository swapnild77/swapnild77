/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.entities;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author M1057685
 *
 */
@Entity
public class Dishes {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int dishId;
	@NotNull
	private String dishName;
	@NotNull
	private double dishPrice;
	@NotNull
	private String dishType;
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private Restaurant restaurant;

	/**
	 * @param dishId     Integer
	 * @param dishName   String
	 * @param dishPrice  double
	 * @param dishType   String
	 * @param restaurant Restaurant
	 */
	public Dishes(int dishId, @NotNull String dishName, @NotNull double dishPrice, @NotNull String dishType,
			Restaurant restaurant) {
		this.dishId = dishId;
		this.dishName = dishName;
		this.dishPrice = dishPrice;
		this.dishType = dishType;
		this.restaurant = restaurant;
	}

	/**
	 * 
	 */
	public Dishes() {
	}

	/**
	 * @return the dishId Integer
	 */
	public int getDishId() {
		return dishId;
	}

	/**
	 * @param dishId the dishId Integer to set
	 */
	public void setDishId(int dishId) {
		this.dishId = dishId;
	}

	/**
	 * @return the dishName String
	 */
	public String getDishName() {
		return dishName;
	}

	/**
	 * @param dishName the dishName String to set
	 */
	public void setDishName(String dishName) {
		this.dishName = dishName;
	}

	/**
	 * @return the dishPrice double
	 */
	public double getDishPrice() {
		return dishPrice;
	}

	/**
	 * @param dishPrice the dishPrice double to set
	 */
	public void setDishPrice(double dishPrice) {
		this.dishPrice = dishPrice;
	}

	/**
	 * @return the dishType String
	 */
	public String getDishType() {
		return dishType;
	}

	/**
	 * @param dishType the dishType String to set
	 */
	public void setDishType(String dishType) {
		this.dishType = dishType;
	}

	/**
	 * @return the restaurant Restaurant
	 */
	public Restaurant getRestaurant() {
		return restaurant;
	}

	/**
	 * @param restaurant the restaurant Restaurant to set
	 */
	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}
}
