package com.mindtree.mvc.booking.restaurant.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mindtree.mvc.booking.restaurant.entities.Block;
import com.mindtree.mvc.booking.restaurant.services.BlockServices;

/**
 * @author M1057685
 *
 */
@Controller
public class BlockController {
	@Autowired
	private BlockServices blockServices;

	@RequestMapping(value = "/")
	private String indexPage() {
		return "index";
	}

	@RequestMapping(value = "/viewBlockPage")
	public String blockPage(Model model) {
		Block block=new Block();
		model.addAttribute("block",block);
		return "blockPage";
	}
	
	@RequestMapping(value = "/saveBlocks",method = RequestMethod.POST)
	public String saveBlock(@ModelAttribute Block block)
	{
		blockServices.addBlocks(block);
		return "index";
	}
}
