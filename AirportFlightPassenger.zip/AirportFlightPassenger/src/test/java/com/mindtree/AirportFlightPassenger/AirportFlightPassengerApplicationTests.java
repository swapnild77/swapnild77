package com.mindtree.AirportFlightPassenger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirportFlightPassengerApplicationTests {

	@Test
	void contextLoads() {
	}

}
