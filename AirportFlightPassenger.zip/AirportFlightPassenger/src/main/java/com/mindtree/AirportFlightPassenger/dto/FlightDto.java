/**
 * 
 */
package com.mindtree.AirportFlightPassenger.dto;

import java.util.List;

import com.mindtree.AirportFlightPassenger.entities.Airport;
import com.mindtree.AirportFlightPassenger.entities.Passenger;

/**
 * @author M1057685
 *
 */
public class FlightDto {
	private String flightId;
	private String flightName;
	private int totalPassengers;
	private double ticketCost;
	private List<Airport> airports;
	private List<Passenger> passengers;

	/**
	 * @param flightId
	 * @param flightName
	 * @param totalPassengers
	 * @param ticketCost
	 * @param totalRevenueGenerated
	 * @param airports
	 * @param passengers
	 */
	public FlightDto(String flightId, String flightName, int totalPassengers, double ticketCost, List<Airport> airports,
			List<Passenger> passengers) {
		this.flightId = flightId;
		this.flightName = flightName;
		this.totalPassengers = totalPassengers;
		this.ticketCost = ticketCost;
		this.airports = airports;
		this.passengers = passengers;
	}

	/**
	 * 
	 */
	public FlightDto() {
	}

	/**
	 * @return the flightId
	 */
	public String getFlightId() {
		return flightId;
	}

	/**
	 * @param flightId the flightId to set
	 */
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}

	/**
	 * @return the flightName
	 */
	public String getFlightName() {
		return flightName;
	}

	/**
	 * @param flightName the flightName to set
	 */
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	/**
	 * @return the totalPassengers
	 */
	public int getTotalPassengers() {
		return totalPassengers;
	}

	/**
	 * @param totalPassengers the totalPassengers to set
	 */
	public void setTotalPassengers(int totalPassengers) {
		this.totalPassengers = totalPassengers;
	}

	/**
	 * @return the ticketCost
	 */
	public double getTicketCost() {
		return ticketCost;
	}

	/**
	 * @param ticketCost the ticketCost to set
	 */
	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}

	/**
	 * @return the airports
	 */
	public List<Airport> getAirports() {
		return airports;
	}

	/**
	 * @param airports the airports to set
	 */
	public void setAirports(List<Airport> airports) {
		this.airports = airports;
	}

	/**
	 * @return the passengers
	 */
	public List<Passenger> getPassengers() {
		return passengers;
	}

	/**
	 * @param passengers the passengers to set
	 */
	public void setPassengers(List<Passenger> passengers) {
		this.passengers = passengers;
	}

}
