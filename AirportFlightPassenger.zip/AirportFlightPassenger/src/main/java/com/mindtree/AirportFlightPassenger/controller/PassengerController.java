/**
 * 
 */
package com.mindtree.AirportFlightPassenger.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.AirportFlightPassenger.dto.PassengerDto;
import com.mindtree.AirportFlightPassenger.exceptions.ApplicationException;
import com.mindtree.AirportFlightPassenger.service.PassengerService;

/**
 * @author M1057685
 *
 */
@RestController
@RequestMapping(value = "/passenger")
public class PassengerController {
	@Autowired
	private PassengerService passengerService;

	@PostMapping(value = "/addPassengers")
	public ResponseEntity<?> addPassenger(@RequestBody PassengerDto passengerDto) throws ApplicationException {
		String result = passengerService.addPassenger(passengerDto);
		return new ResponseEntity<String>(result, HttpStatus.ACCEPTED);
	}

	@PostMapping(value = "/boardPassengerToFlight/{passengerId}/{flightId}")
	public ResponseEntity<?> boardPassengerToFlight(@PathVariable int passengerId, @PathVariable String flightId)
			throws ApplicationException {
		String result = passengerService.boardPassengerToFlight(passengerId, flightId);
		return new ResponseEntity<String>(result, HttpStatus.ACCEPTED);
	}
}
