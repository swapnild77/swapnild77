/**
 * 
 */
package com.mindtree.AirportFlightPassenger.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.AirportFlightPassenger.dto.FlightDto;
import com.mindtree.AirportFlightPassenger.exceptions.ApplicationException;
import com.mindtree.AirportFlightPassenger.service.FlightService;

/**
 * @author M1057685
 *
 */
@RestController
@RequestMapping(value = "/flight")
public class FlightController {
	@Autowired
	private FlightService flightService;

	@PostMapping(value = "/addFlights")
	public ResponseEntity<?> addFlights(@RequestBody FlightDto flightDto) throws ApplicationException {
		String result = flightService.addFlights(flightDto);
		return new ResponseEntity<String>(result, HttpStatus.ACCEPTED);
	}

	@PostMapping(value = "/assignFlightToAirport/{airportId}/{flightId}")
	public ResponseEntity<?> assignFlightToAirport(@PathVariable int airportId, @PathVariable String flightId)
			throws ApplicationException {
		String result = flightService.assignFlightToAirport(airportId, flightId);
		return new ResponseEntity<String>(result, HttpStatus.ACCEPTED);
	}

	@DeleteMapping(value = "/deleteFlightByFlightId/{flightId}")
	public ResponseEntity<?> deleteFlightsByFlightId(@PathVariable String flightId) throws ApplicationException {
		String result = flightService.deleteFlightsByFlightId(flightId);
		return new ResponseEntity<String>(result, HttpStatus.ACCEPTED);
	}
}
