/**
 * 
 */
package com.mindtree.AirportFlightPassenger.service;

import org.springframework.stereotype.Service;

import com.mindtree.AirportFlightPassenger.dto.PassengerDto;
import com.mindtree.AirportFlightPassenger.exceptions.service.ServiceException;

/**
 * @author M1057685
 *
 */
@Service
public interface PassengerService {

	/**
	 * @param passengerDto
	 * @return
	 * @throws ServiceException
	 */
	public String addPassenger(PassengerDto passengerDto) throws ServiceException;

	/**
	 * @param passengerId
	 * @param flightId
	 * @return
	 * @throws ServiceException
	 */
	public String boardPassengerToFlight(int passengerId, String flightId) throws ServiceException;
}
