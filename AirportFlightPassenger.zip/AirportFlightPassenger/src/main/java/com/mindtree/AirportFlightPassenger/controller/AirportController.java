/**
 * 
 */
package com.mindtree.AirportFlightPassenger.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.AirportFlightPassenger.dto.AirportDto;
import com.mindtree.AirportFlightPassenger.exceptions.ApplicationException;
import com.mindtree.AirportFlightPassenger.service.AirportService;

/**
 * @author M1057685
 *
 */
@RestController
@RequestMapping(value = "/airport")
public class AirportController {
	@Autowired
	private AirportService airportService;

	@PostMapping(value = "/addAirports")
	public ResponseEntity<?> addAirports(@RequestBody AirportDto airportDto) throws ApplicationException {
		String result = airportService.addAirports(airportDto);
		return new ResponseEntity<String>(result, HttpStatus.ACCEPTED);
	}
	
	@GetMapping(value = "/getTotalRevenueDetails")
	public ResponseEntity<?> getTotalRevenueDetails()
	{
		Map<String,Double> getDetails=airportService.getTotalRevenueDetails();
		return new ResponseEntity<Map<String,Double>>(getDetails,HttpStatus.ACCEPTED);
	}
}
