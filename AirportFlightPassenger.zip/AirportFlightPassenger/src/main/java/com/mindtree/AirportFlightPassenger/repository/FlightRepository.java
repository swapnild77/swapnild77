/**
 * 
 */
package com.mindtree.AirportFlightPassenger.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mindtree.AirportFlightPassenger.entities.Flight;

/**
 * @author M1057685
 *
 */
@Repository
public interface FlightRepository extends JpaRepository<Flight, Integer> {

	/**
	 * @param flightId
	 * @return
	 */
	@Query("SELECT u FROM Flight u WHERE flightId=?1")
	public Flight displayFlightByFlightId(String flightId);

	/**
	 * @param flightId
	 */
	@Query("DELETE FROM Flight u WHERE flightId=?1")
	@Modifying
	@Transactional
	public void deleteFlight(String flightId);
}
