/**
 * 
 */
package com.mindtree.AirportFlightPassenger.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.validation.constraints.NotNull;

import java.util.*;

/**
 * @author M1057685
 *
 */
@Entity
public class Passenger {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int passengerId;
	@NotNull
	private String passengerName;
	@NotNull
	private double accountBalance;
	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
	private List<Flight> flights;

	/**
	 * @param passengerId
	 * @param passengerName
	 * @param accountBalance
	 * @param flights
	 */
	public Passenger(int passengerId, @NotNull String passengerName, @NotNull double accountBalance,
			List<Flight> flights) {
		this.passengerId = passengerId;
		this.passengerName = passengerName;
		this.accountBalance = accountBalance;
		this.flights = flights;
	}

	/**
	 * 
	 */
	public Passenger() {
	}

	/**
	 * @return the passengerId
	 */
	public int getPassengerId() {
		return passengerId;
	}

	/**
	 * @param passengerId the passengerId to set
	 */
	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}

	/**
	 * @return the passengerName
	 */
	public String getPassengerName() {
		return passengerName;
	}

	/**
	 * @param passengerName the passengerName to set
	 */
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	/**
	 * @return the accountBalance
	 */
	public double getAccountBalance() {
		return accountBalance;
	}

	/**
	 * @param accountBalance the accountBalance to set
	 */
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	/**
	 * @return the flights
	 */
	public List<Flight> getFlights() {
		return flights;
	}

	/**
	 * @param flights the flights to set
	 */
	public void setFlights(List<Flight> flights) {
		this.flights = flights;
	}

}
