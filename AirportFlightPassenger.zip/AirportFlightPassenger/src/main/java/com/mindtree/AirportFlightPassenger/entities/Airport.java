/**
 * 
 */
package com.mindtree.AirportFlightPassenger.entities;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.MapKeyColumn;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.*;

/**
 * @author M1057685
 *
 */
@Entity
public class Airport {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int aiportId;
	@NotNull
	private String airportName;
	@NotNull
	private int totalFlights;
	@ManyToMany(mappedBy = "airports", fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	private List<Flight> flights;
	@ElementCollection
	@MapKeyColumn
	@JsonIgnore
	private Map<String, Double> map = new HashMap<String, Double>();

	/**
	 * @param aiportId
	 * @param airportName
	 * @param totalFlights
	 * @param flights
	 * @param map
	 */
	public Airport(int aiportId, @NotNull String airportName, @NotNull int totalFlights, List<Flight> flights,
			Map<String, Double> map) {
		this.aiportId = aiportId;
		this.airportName = airportName;
		this.totalFlights = totalFlights;
		this.flights = flights;
		this.map = map;
	}

	/**
	 * 
	 */
	public Airport() {
	}

	/**
	 * @return the aiportId
	 */
	public int getAiportId() {
		return aiportId;
	}

	/**
	 * @param aiportId the aiportId to set
	 */
	public void setAiportId(int aiportId) {
		this.aiportId = aiportId;
	}

	/**
	 * @return the airportName
	 */
	public String getAirportName() {
		return airportName;
	}

	/**
	 * @param airportName the airportName to set
	 */
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}

	/**
	 * @return the totalFlights
	 */
	public int getTotalFlights() {
		return totalFlights;
	}

	/**
	 * @param totalFlights the totalFlights to set
	 */
	public void setTotalFlights(int totalFlights) {
		this.totalFlights = totalFlights;
	}

	/**
	 * @return the flights
	 */
	public List<Flight> getFlights() {
		return flights;
	}

	/**
	 * @param flights the flights to set
	 */
	public void setFlights(List<Flight> flights) {
		this.flights = flights;
	}

	/**
	 * @return the map
	 */
	public Map<String, Double> getMap() {
		return map;
	}

	/**
	 * @param map the map to set
	 */
	public void setMap(Map<String, Double> map) {
		this.map = map;
	}

}
