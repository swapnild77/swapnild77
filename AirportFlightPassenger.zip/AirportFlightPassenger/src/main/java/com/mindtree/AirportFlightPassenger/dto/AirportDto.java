/**
 * 
 */
package com.mindtree.AirportFlightPassenger.dto;

import java.util.List;

import com.mindtree.AirportFlightPassenger.entities.Flight;

/**
 * @author M1057685
 *
 */
public class AirportDto {
	private String airportName;
	private int totalFlights;
	private List<Flight> flights;

	/**
	 * @param airportName
	 * @param totalFlights
	 * @param flights
	 */
	public AirportDto(String airportName, int totalFlights, List<Flight> flights) {
		this.airportName = airportName;
		this.totalFlights = totalFlights;
		this.flights = flights;
	}

	/**
	 * 
	 */
	public AirportDto() {
	}

	/**
	 * @return the airportName
	 */
	public String getAirportName() {
		return airportName;
	}

	/**
	 * @param airportName the airportName to set
	 */
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}

	/**
	 * @return the totalFlights
	 */
	public int getTotalFlights() {
		return totalFlights;
	}

	/**
	 * @param totalFlights the totalFlights to set
	 */
	public void setTotalFlights(int totalFlights) {
		this.totalFlights = totalFlights;
	}

	/**
	 * @return the flights
	 */
	public List<Flight> getFlights() {
		return flights;
	}

	/**
	 * @param flights the flights to set
	 */
	public void setFlights(List<Flight> flights) {
		this.flights = flights;
	}

}
