/**
 * 
 */
package com.mindtree.AirportFlightPassenger.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.mindtree.AirportFlightPassenger.dto.AirportDto;
import com.mindtree.AirportFlightPassenger.exceptions.service.ServiceException;

/**
 * @author M1057685
 *
 */
@Service
public interface AirportService {

	/**
	 * @param airportDto
	 * @return
	 * @throws ServiceException
	 */
	public String addAirports(AirportDto airportDto) throws ServiceException;

	/**
	 * @return
	 */
	public Map<String, Double> getTotalRevenueDetails();

}
