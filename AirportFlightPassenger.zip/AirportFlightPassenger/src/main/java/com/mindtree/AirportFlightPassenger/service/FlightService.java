/**
 * 
 */
package com.mindtree.AirportFlightPassenger.service;



import org.springframework.stereotype.Service;

import com.mindtree.AirportFlightPassenger.dto.FlightDto;
import com.mindtree.AirportFlightPassenger.exceptions.service.ServiceException;

/**
 * @author M1057685
 *
 */
@Service
public interface FlightService {

	/**
	 * @param flightDto
	 * @return
	 * @throws ServiceException
	 */
	public String addFlights(FlightDto flightDto) throws ServiceException;

	/**
	 * @param airportId
	 * @param flightId
	 * @return
	 * @throws ServiceException
	 */
	public String assignFlightToAirport(int airportId, String flightId) throws ServiceException;

	/**
	 * @param flightId
	 * @return
	 * @throws ServiceException
	 */
	public String deleteFlightsByFlightId(String flightId) throws ServiceException;
}
