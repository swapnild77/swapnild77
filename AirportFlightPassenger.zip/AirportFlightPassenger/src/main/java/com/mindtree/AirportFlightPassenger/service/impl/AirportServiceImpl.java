/**
 * 
 */
package com.mindtree.AirportFlightPassenger.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.AirportFlightPassenger.dto.AirportDto;
import com.mindtree.AirportFlightPassenger.entities.Airport;
import com.mindtree.AirportFlightPassenger.exceptions.service.ServiceException;
import com.mindtree.AirportFlightPassenger.exceptions.service.custom.AirportNameCannotBeNullException;
import com.mindtree.AirportFlightPassenger.repository.AirportRepository;
import com.mindtree.AirportFlightPassenger.service.AirportService;

/**
 * @author M1057685
 *
 */
@Service
public class AirportServiceImpl implements AirportService {
	@Autowired
	private AirportRepository airportRepository;
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public String addAirports(AirportDto airportDto) throws ServiceException {
		if (airportDto.getAirportName() == null) {
			throw new AirportNameCannotBeNullException("Airport Name Cannot Be Null Exception");
		} else {
			Airport airport = modelMapper.map(airportDto, Airport.class);
			airportRepository.save(airport);
			return "AIRPORT ADDED SUCCESSFULLY";
		}
	}

	@Override
	public Map<String, Double> getTotalRevenueDetails() {
		List<Airport> getAirportList = airportRepository.findAll();
		Map<String, Double> getTotalRevenue = new HashMap<String, Double>();
		for (Airport airport : getAirportList) {
			getTotalRevenue.put(airport.getAirportName(), airport.getFlights().stream()
					.mapToDouble(m -> m.getTotalRevenueGenerated()).reduce(0.0, (a, b) -> a + b));
		}
		return getTotalRevenue;
	}

}
