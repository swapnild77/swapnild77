/**
 * 
 */
package com.mindtree.AirportFlightPassenger.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.mindtree.AirportFlightPassenger.dto.ErrorDto;

/**
 * @author M1057685
 *
 */
@RestControllerAdvice
public class ExceptionHandling {
	private ResponseEntity<Object> builtResponseEntity(ErrorDto errorDto, HttpStatus httpStatus) {
		return ResponseEntity.status(httpStatus).header("status", String.valueOf(httpStatus)).body(errorDto);
	}

	@ExceptionHandler(ApplicationException.class)
	@ResponseStatus(value = HttpStatus.CONFLICT)
	public final ResponseEntity<Object> applicationException(ApplicationException ex, WebRequest request) {
		ErrorDto dto = new ErrorDto();
		dto.setError(true);
		dto.setErrorMessage(ex.getMessage());
		dto.setErrorType(ex.getClass().getCanonicalName());
		dto.setHttpStatusCode(400);
		dto.setHttpStatus(HttpStatus.CONFLICT);
		return builtResponseEntity(dto, HttpStatus.CONFLICT);
	}
}
