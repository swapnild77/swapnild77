/**
 * 
 */
package com.mindtree.AirportFlightPassenger.dto;

import org.springframework.http.HttpStatus;

/**
 * @author M1057685
 *
 */
public class ErrorDto {
	private String errorMessage;
	private String errorType;
	private HttpStatus httpStatus;
	private int httpStatusCode;
	private boolean error;

	public ErrorDto(String errorMessage, String errorType, HttpStatus httpStatus, int httpStatusCode, boolean error) {
		this.errorMessage = errorMessage;
		this.errorType = errorType;
		this.httpStatus = httpStatus;
		this.httpStatusCode = httpStatusCode;
		this.error = error;
	}

	public ErrorDto() {
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorType() {
		return errorType;
	}

	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}

	public int getHttpStatusCode() {
		return httpStatusCode;
	}

	public void setHttpStatusCode(int httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}
}
