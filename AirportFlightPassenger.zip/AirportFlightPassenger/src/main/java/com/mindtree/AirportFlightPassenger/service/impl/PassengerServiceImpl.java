/**
 * 
 */
package com.mindtree.AirportFlightPassenger.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.AirportFlightPassenger.dto.PassengerDto;
import com.mindtree.AirportFlightPassenger.entities.Flight;
import com.mindtree.AirportFlightPassenger.entities.Passenger;
import com.mindtree.AirportFlightPassenger.exceptions.service.ServiceException;
import com.mindtree.AirportFlightPassenger.exceptions.service.custom.FlightNotFoundException;
import com.mindtree.AirportFlightPassenger.exceptions.service.custom.InsufficientAccountBalanceException;
import com.mindtree.AirportFlightPassenger.exceptions.service.custom.PassengerNameCannotBeNullException;
import com.mindtree.AirportFlightPassenger.exceptions.service.custom.PassengerNotFoundException;
import com.mindtree.AirportFlightPassenger.repository.FlightRepository;
import com.mindtree.AirportFlightPassenger.repository.PassengerRepository;
import com.mindtree.AirportFlightPassenger.service.PassengerService;

/**
 * @author M1057685
 *
 */
@Service
public class PassengerServiceImpl implements PassengerService {
	@Autowired
	private PassengerRepository passengerRepository;
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private FlightRepository flightRepository;

	@Override
	public String addPassenger(PassengerDto passengerDto) throws ServiceException {
		if (passengerDto.getPassengerName() == null) {
			throw new PassengerNameCannotBeNullException("Passenger Name Cannot Be Null Exception");
		} else {
			Passenger passenger = modelMapper.map(passengerDto, Passenger.class);
			passengerRepository.save(passenger);
			return "PASSENGER ADDED SUCCESSFULLY";
		}

	}

	@Override
	public String boardPassengerToFlight(int passengerId, String flightId) throws ServiceException {
		Passenger passenger = passengerRepository.findById(passengerId)
				.orElseThrow(() -> new PassengerNotFoundException("Passenger Not Found Exception"));
		Flight flight = flightRepository.displayFlightByFlightId(flightId);
		if (flight != null) {
			if (passenger.getAccountBalance() < flight.getTicketCost()) {
				throw new InsufficientAccountBalanceException("Insufficient Account Balance Exception");
			} else {
				double accountBalanceLeftAfterBookingFlight = passenger.getAccountBalance() - flight.getTicketCost();
				passenger.setAccountBalance(accountBalanceLeftAfterBookingFlight);
				passenger.getFlights().add(flight);
				flight.setTotalRevenueGenerated(flight.getTicketCost());
				flight.getPassengers().add(passenger);
				flightRepository.save(flight);
				passengerRepository.save(passenger);
				return "PASSENGER BOARED";
			}
		} else {
			throw new FlightNotFoundException("Flight Not Found Exception");
		}

	}

}
