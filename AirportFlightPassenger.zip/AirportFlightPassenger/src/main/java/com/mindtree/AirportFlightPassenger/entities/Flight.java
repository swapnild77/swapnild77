/**
 * 
 */
package com.mindtree.AirportFlightPassenger.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.validation.constraints.NotNull;
import java.util.*;

/**
 * @author M1057685
 *
 */
@Entity
public class Flight {
	@Id
	private String flightId;
	@Column(unique = true)
	private String flightName;
	@NotNull
	private int totalPassengers;
	@NotNull
	private double ticketCost;
	@NotNull
	private double totalRevenueGenerated;
	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
	private List<Airport> airports;
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST,mappedBy = "flights")
	private List<Passenger> passengers;

	/**
	 * @param slNo
	 * @param flightId
	 * @param flightName
	 * @param totalPassengers
	 * @param ticketCost
	 * @param totalRevenueGenerated
	 * @param airports
	 * @param passengers
	 */
	public Flight(String flightId, String flightName, @NotNull int totalPassengers, @NotNull double ticketCost,
			@NotNull double totalRevenueGenerated, List<Airport> airports, List<Passenger> passengers) {
		this.flightId = flightId;
		this.flightName = flightName;
		this.totalPassengers = totalPassengers;
		this.ticketCost = ticketCost;
		this.totalRevenueGenerated = totalRevenueGenerated;
		this.airports = airports;
		this.passengers = passengers;
	}

	/**
	 * 
	 */
	public Flight() {
	}

	/**
	 * @return the flightId
	 */
	public String getFlightId() {
		return flightId;
	}

	/**
	 * @param flightId the flightId to set
	 */
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}

	/**
	 * @return the flightName
	 */
	public String getFlightName() {
		return flightName;
	}

	/**
	 * @param flightName the flightName to set
	 */
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	/**
	 * @return the totalPassengers
	 */
	public int getTotalPassengers() {
		return totalPassengers;
	}

	/**
	 * @param totalPassengers the totalPassengers to set
	 */
	public void setTotalPassengers(int totalPassengers) {
		this.totalPassengers = totalPassengers;
	}

	/**
	 * @return the ticketCost
	 */
	public double getTicketCost() {
		return ticketCost;
	}

	/**
	 * @param ticketCost the ticketCost to set
	 */
	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}

	/**
	 * @return the totalRevenueGenerated
	 */
	public double getTotalRevenueGenerated() {
		return totalRevenueGenerated;
	}

	/**
	 * @param totalRevenueGenerated the totalRevenueGenerated to set
	 */
	public void setTotalRevenueGenerated(double totalRevenueGenerated) {
		this.totalRevenueGenerated = totalRevenueGenerated;
	}

	/**
	 * @return the airports
	 */
	public List<Airport> getAirports() {
		return airports;
	}

	/**
	 * @param airports the airports to set
	 */
	public void setAirports(List<Airport> airports) {
		this.airports = airports;
	}

	/**
	 * @return the passengers
	 */
	public List<Passenger> getPassengers() {
		return passengers;
	}

	/**
	 * @param passengers the passengers to set
	 */
	public void setPassengers(List<Passenger> passengers) {
		this.passengers = passengers;
	}

}
