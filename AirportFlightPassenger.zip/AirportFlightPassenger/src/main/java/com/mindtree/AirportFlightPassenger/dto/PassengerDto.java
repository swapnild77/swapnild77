/**
 * 
 */
package com.mindtree.AirportFlightPassenger.dto;

import java.util.List;

import com.mindtree.AirportFlightPassenger.entities.Flight;

/**
 * @author M1057685
 *
 */
public class PassengerDto {
	private String passengerName;
	private double accountBalance;
	private List<Flight> flights;

	/**
	 * @param passengerName
	 * @param accountBalance
	 * @param flights
	 */
	public PassengerDto(String passengerName, double accountBalance, List<Flight> flights) {
		this.passengerName = passengerName;
		this.accountBalance = accountBalance;
		this.flights = flights;
	}

	/**
	 * 
	 */
	public PassengerDto() {
	}

	/**
	 * @return the passengerName
	 */
	public String getPassengerName() {
		return passengerName;
	}

	/**
	 * @param passengerName the passengerName to set
	 */
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	/**
	 * @return the accountBalance
	 */
	public double getAccountBalance() {
		return accountBalance;
	}

	/**
	 * @param accountBalance the accountBalance to set
	 */
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	/**
	 * @return the flights
	 */
	public List<Flight> getFlights() {
		return flights;
	}

	/**
	 * @param flights the flights to set
	 */
	public void setFlights(List<Flight> flights) {
		this.flights = flights;
	}

}
