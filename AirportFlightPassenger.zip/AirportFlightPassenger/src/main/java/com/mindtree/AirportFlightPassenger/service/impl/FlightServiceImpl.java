/**
 * 
 */
package com.mindtree.AirportFlightPassenger.service.impl;

import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.AirportFlightPassenger.dto.FlightDto;
import com.mindtree.AirportFlightPassenger.entities.Airport;
import com.mindtree.AirportFlightPassenger.entities.Flight;
import com.mindtree.AirportFlightPassenger.exceptions.service.ServiceException;
import com.mindtree.AirportFlightPassenger.exceptions.service.custom.AirportNotFoundException;
import com.mindtree.AirportFlightPassenger.exceptions.service.custom.FlightIdAlreadyExistException;
import com.mindtree.AirportFlightPassenger.exceptions.service.custom.FlightNameAlreadyExistException;
import com.mindtree.AirportFlightPassenger.exceptions.service.custom.FlightNotFoundException;
import com.mindtree.AirportFlightPassenger.exceptions.service.custom.TotalFlightSizeExceedException;
import com.mindtree.AirportFlightPassenger.repository.AirportRepository;
import com.mindtree.AirportFlightPassenger.repository.FlightRepository;
import com.mindtree.AirportFlightPassenger.service.FlightService;

/**
 * @author M1057685
 *
 */
@Service
public class FlightServiceImpl implements FlightService {
	@Autowired
	private FlightRepository flightRepository;
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private AirportRepository airportRepository;

	@Override
	public String addFlights(FlightDto flightDto) throws ServiceException {
		List<Flight> getFlightsFromRepository = flightRepository.findAll();
		if (getFlightsFromRepository != null) {
			boolean checkId = getFlightsFromRepository.stream()
					.anyMatch(f -> f.getFlightId().equals(flightDto.getFlightId()));
			if (checkId == false) {
				boolean checkName = getFlightsFromRepository.stream()
						.anyMatch(f -> f.getFlightName().equals(flightDto.getFlightName()));
				if (checkName == false) {
					Flight flight = modelMapper.map(flightDto, Flight.class);
					flightRepository.save(flight);
					return "FLIGHT ADDED SUCCESSFULLY";
				} else {
					throw new FlightNameAlreadyExistException("Flight Name Already Exist Exception");
				}
			} else
				throw new FlightIdAlreadyExistException("Flight Id Already ExistException");
		} else {
			Flight flight = modelMapper.map(flightDto, Flight.class);
			flightRepository.save(flight);
			return "FLIGHT ADDED SUCCESSFULLY";
		}
	}

	@Override
	public String assignFlightToAirport(int airportId, String flightId) throws ServiceException {
		Airport airport = airportRepository.findById(airportId)
				.orElseThrow(() -> new AirportNotFoundException("Airport Not Found Exception"));
		Flight flight = flightRepository.displayFlightByFlightId(flightId);
		if (flight != null) {
			if (airport.getTotalFlights() > airport.getFlights().size()) {
				airport.getFlights().add(flight);
				flight.getAirports().add(airport);
				airportRepository.save(airport);
				flightRepository.save(flight);
				return "SUCCESSFULLY ASSIGNED";
			} else
				throw new TotalFlightSizeExceedException("Total Flight Size Exceed Exception");
		} else {
			throw new FlightNotFoundException("Flight Not Found Exception");
		}
	}

	@Override
	public String deleteFlightsByFlightId(String flightId) throws ServiceException {
		Flight flight = flightRepository.displayFlightByFlightId(flightId);
		if (flight == null)
			throw new FlightNotFoundException("Flight Not Found Exception");
		else {
			flightRepository.deleteFlight(flightId);
			return "SUCCESSFULLY DELETED";
		}
	}
}
