/**
 * 
 */
package com.mindtree.AirportFlightPassenger.dto;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author M1057685
 *
 */
@Configuration
public class ModelApp {
	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}
}
