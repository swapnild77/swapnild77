/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mindtree.mvc.booking.restaurant.entities.Block;
import com.mindtree.mvc.booking.restaurant.entities.Restaurant;
import com.mindtree.mvc.booking.restaurant.repository.BlockRepository;
import com.mindtree.mvc.booking.restaurant.repository.RestaurantRepository;
import com.mindtree.mvc.booking.restaurant.services.impl.RestaurantServiceImpl;

/**
 * @author M1057685
 *
 */
@SpringBootTest
//@RunWith(MockitoJUnitRunner.class)
@RunWith(MockitoJUnitRunner.Silent.class)
//@WebMvcTest(RestaurantController.class)
//@RunWith(SpringJUnit4ClassRunner.class)
public class RestaurantTest {
	@InjectMocks
	private RestaurantServiceImpl restaurantServiceImpl;
	@Mock
	private RestaurantRepository restaurantRepository;
	@Mock
	private BlockRepository blockRepository;
	private Restaurant restaurant = new Restaurant();
	private Block block = new Block();

	@Before
	public void addRestaurant() {
		MockitoAnnotations.initMocks(this);
		restaurant.setRestaurantId(1);
		restaurant.setRestaurantName("RELAX BAR");
		restaurant.setRestaurantType("BAR");
		restaurant.setRestauranRate(4.5);
		when(blockRepository.findById(1)).thenReturn(Optional.of(block));
		restaurant.setBlock(block);
		Set<Restaurant> getList = new HashSet<Restaurant>();
		getList.add(restaurant);
		block.setRestaurant(getList);
		when(restaurantRepository.save(restaurant)).thenReturn(restaurant);
//		when(restaurantServiceImpl.saveRestaurants(block, restaurant)).thenReturn(restaurant);
	}

	@Test
	public void saveRestaturant() {
		assertEquals(restaurant,restaurantServiceImpl.saveRestaurants(block, restaurant) );
		assertEquals(restaurant, restaurant);
	}

	@Before
	public void setUpBlockRepo() {
		MockitoAnnotations.initMocks(this);
		List<Block> getBlockList = new ArrayList<Block>();
		getBlockList.add(new Block(1, "FOODCOURT", null));
		getBlockList.add(new Block(2, "BAR", null));
		when(blockRepository.findAll()).thenReturn(getBlockList);
	}

	@Test
	public void findAllBlock() {
		List<Block> getBlockList = blockRepository.findAll();
		assertEquals(getBlockList, restaurantServiceImpl.getBlockName());
	}

	@Before
	public void setUpRestaurantRepo() {
		MockitoAnnotations.initMocks(this);
		List<Restaurant> restaurantList = new ArrayList<Restaurant>();
		restaurantList.add(new Restaurant(1, "XXX", "BAR", 3.5, block, null));
		restaurantList.add(new Restaurant(2, "XXXYYY", "BAR", 3.9, block, null));
		when(restaurantRepository.findAll()).thenReturn(restaurantList);
	}

	@Test
	public void findAllRestaurant() {
		List<Restaurant> restaurantList = restaurantRepository.findAll();
		assertEquals(restaurantList, restaurantServiceImpl.getAllRestaurant());
	}

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		Set<Restaurant> restaurantList = new HashSet<Restaurant>();
		restaurantList.add(new Restaurant(1, "XXX", "BAR", 3.5, block, null));
		restaurantList.add(new Restaurant(2, "XXXYYY", "BAR", 3.9, block, null));
		block.setRestaurant(restaurantList);
		Set<Restaurant> getRestaurants = block.getRestaurant();
		List<Restaurant> details = new ArrayList<Restaurant>(getRestaurants);
		when(restaurantRepository.findAll()).thenReturn(details);
	}

	@Test
	public void getRestaurantListByBlockName() {
		Set<Restaurant> getRestaurants = block.getRestaurant();
		List<Restaurant> details = new ArrayList<Restaurant>(getRestaurants);
		assertEquals(details, restaurantServiceImpl.getDetailsByBlockName(block));
	}

	@Before
	public void setUpAgain() {
		List<Restaurant> restaurantList = new ArrayList<Restaurant>();
		restaurantList.add(new Restaurant(1, "XXX", "BAR", 3.5, block, null));
		restaurantList.add(new Restaurant(2, "XXXYYY", "BAR", 3.9, block, null));
		List<Restaurant> restautantRepo = restaurantRepository.findAll();
		when(restaurantRepository.getAllByRestaurantType("BAR")).thenReturn(restautantRepo);
	}

	@Test
	public void getRestaurantByType() {
		List<Restaurant> restautantRepo = restaurantRepository.findAll();
		assertEquals(restautantRepo, restaurantServiceImpl.getAllRestaurantBtType(restaurant));
	}
}
