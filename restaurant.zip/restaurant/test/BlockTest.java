/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mindtree.mvc.booking.restaurant.entities.Block;
import com.mindtree.mvc.booking.restaurant.repository.BlockRepository;
import com.mindtree.mvc.booking.restaurant.services.impl.BlockServiceImpl;

/**
 * @author M1057685
 *
 */
@SpringBootTest
//@RunWith(SpringJUnit4ClassRunner.class)
@RunWith(MockitoJUnitRunner.Silent.class)
//@RunWith(MockitoJUnitRunner.class)
public class BlockTest {
	@InjectMocks
	private BlockServiceImpl blockServiceImpl;
	@Mock
	private BlockRepository blockRepository;
	private Block block = new Block();

	@Before
	public void setUp() {
		block.setBlockName("FOODCOURT");
		block.setBlockId(1);
		block.setRestaurant(null);
		when(blockRepository.save(block)).thenReturn(block);
	}

	@Test
	public void addBlock() {
		assertEquals(block, blockServiceImpl.addBlocks(block));
	}
}
