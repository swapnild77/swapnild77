/**
 * 
 */
package com.mindtree.mvc.booking.restaurant.test;
//import static org.hamcrest.Matchers.*;
import org.hamcrest.beans.HasProperty;
import org.hamcrest.collection.*;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.mvc.booking.restaurant.controller.RestaurantController;
import com.mindtree.mvc.booking.restaurant.entities.Block;
import com.mindtree.mvc.booking.restaurant.entities.Restaurant;
import com.mindtree.mvc.booking.restaurant.services.RestaurantService;

/**
 * @author M1057685
 *
 */
@SpringBootTest
@RunWith(MockitoJUnitRunner.Silent.class)
public class RestaurantControllerTest {
	@InjectMocks
	private RestaurantController restaurantController;
	@Mock
	private RestaurantService restaurantService;
	private MockMvc mockMvc;
	Restaurant restaurant=new Restaurant();
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(restaurantController).build();
	}
	@Test
	public void displayBlockName() throws Exception
	{
		List<Block> getBlockName=new ArrayList<Block>();
		getBlockName.add(new Block(1, "SWAPNIL", null));
		getBlockName.add(new Block(2, "VIKAS", null));
		when(restaurantService.getBlockName()).thenReturn(getBlockName);
		mockMvc.perform(post("/goRestaurantPage")).andExpect(status().isOk()).andExpect(view().name("restaurantPage"))
		.andExpect(forwardedUrl("restaurantPage"))
		.andExpect(model().attribute("restaurant", HasProperty.hasProperty("restaurantId")))
		.andExpect(model().attribute("restaurant", HasProperty.hasProperty("restaurantName")))
		.andExpect(model().attribute("restaurant", HasProperty.hasProperty("restaurantType")))
		.andExpect(model().attribute("restaurant", HasProperty.hasProperty("restauranRate")))
		.andExpect(model().attribute("restaurant", HasProperty.hasProperty("block")))
		.andExpect(model().attribute("restaurant", HasProperty.hasProperty("dishes")))
		.andExpect(model().attribute("block", HasProperty.hasProperty("blockId")))
		.andExpect(model().attribute("block", HasProperty.hasProperty("blockName")))
		.andExpect(model().attribute("block", HasProperty.hasProperty("restaurant")));
//		.andExpect(model().attribute("blockNameList", HasProperty.hasProperty(getBlockName.))); 
	}
}
