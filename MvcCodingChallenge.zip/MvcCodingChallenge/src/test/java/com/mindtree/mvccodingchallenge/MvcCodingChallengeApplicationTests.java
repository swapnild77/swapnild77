package com.mindtree.mvccodingchallenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcCodingChallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
