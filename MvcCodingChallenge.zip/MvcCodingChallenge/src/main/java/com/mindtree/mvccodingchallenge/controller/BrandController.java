/**
 * 
 */
package com.mindtree.mvccodingchallenge.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.*;
import com.mindtree.mvccodingchallenge.entities.Brand;
import com.mindtree.mvccodingchallenge.entities.Catagory;
import com.mindtree.mvccodingchallenge.entities.Jacket;
import com.mindtree.mvccodingchallenge.entities.Shirt;
import com.mindtree.mvccodingchallenge.service.BrandService;
import com.mindtree.mvccodingchallenge.service.CatagoryService;

/**
 * @author M1057685
 *
 */
@Controller
public class BrandController {
	@Autowired
	private BrandService brandService;
	@Autowired
	private CatagoryService catagoryService;

	@RequestMapping(value = "/viewBrandPage")
	public String viewBrandPage(Model model) {
		Brand brand = new Brand();
		model.addAttribute("brand", brand);
		List<Brand> getBrandList = brandService.getBrandList();
		model.addAttribute("getBrandList", getBrandList);
		List<Catagory> getCatagoryList = catagoryService.getCatagoryList();
		model.addAttribute("getCatagoryList", getCatagoryList);
		return "viewBrandPage";
	}

	@RequestMapping(value = "/saveBrand")
	public String saveBrand(@ModelAttribute(value = "brand") Brand brand, Model model) {
		brandService.saveBrand(brand);
		List<Brand> getBrandList = brandService.getBrandList();
		model.addAttribute("getBrandList", getBrandList);
		List<Catagory> getCatagoryList = catagoryService.getCatagoryList();
		model.addAttribute("getCatagoryList", getCatagoryList);
		return "viewBrandPage";
	}

	@RequestMapping(value = "/assign")
	public String assignBrands(@RequestParam(value = "catagory") int catagoryId,
			@RequestParam(value = "brand") int brandId, Model model) {
		brandService.assignBrand(catagoryId, brandId);
		return "redirect:/";
	}
	
	@RequestMapping(value = "/detailsBrand/{brandId}")
	public String shirtJacketPage(@PathVariable int brandId,Model model)
	{
		List<Shirt> getShirtList=brandService.getAllShirts(brandId);
		List<Jacket> getJacketList=brandService.getAlljackets(brandId);
		model.addAttribute("getShirtList", getShirtList);
		model.addAttribute("getJacketList", getJacketList);
		String brandName=brandService.getBrandName(brandId);
		model.addAttribute("brandName", brandName);
		return "shirtJacketPage";
	}
}
