/**
 * 
 */
package com.mindtree.mvccodingchallenge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mindtree.mvccodingchallenge.entities.Brand;
import com.mindtree.mvccodingchallenge.entities.Jacket;
import com.mindtree.mvccodingchallenge.service.BrandService;
import com.mindtree.mvccodingchallenge.service.JacketService;

/**
 * @author M1057685
 *
 */
@Controller
public class JacketController {
	@Autowired
	private BrandService brandService;
	@Autowired
	private JacketService jacketService;

	@RequestMapping(value = "/viewJacketPage")
	public String viewJacketPage(Model model) {
		List<Brand> getBrandList = brandService.getBrandList();
		model.addAttribute("getBrandList", getBrandList);
		Jacket jacket = new Jacket();
		model.addAttribute("jacket", jacket);
		return "viewJacketPage";
	}
	
	@RequestMapping(value = "/saveJacket")
	public String addJacket(@ModelAttribute(value = "jacket") Jacket jacket)
	{
		jacketService.addJacket(jacket);
		return "redirect:/";
	}
}
