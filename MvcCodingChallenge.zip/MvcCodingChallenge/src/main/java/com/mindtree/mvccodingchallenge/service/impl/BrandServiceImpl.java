/**
 * 
 */
package com.mindtree.mvccodingchallenge.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.mvccodingchallenge.entities.Brand;
import com.mindtree.mvccodingchallenge.entities.Catagory;
import com.mindtree.mvccodingchallenge.entities.Jacket;
import com.mindtree.mvccodingchallenge.entities.Shirt;
import com.mindtree.mvccodingchallenge.repository.BrandRepository;
import com.mindtree.mvccodingchallenge.repository.CatagoryRepository;
import com.mindtree.mvccodingchallenge.service.BrandService;

/**
 * @author M1057685
 *
 */
@Service
public class BrandServiceImpl implements BrandService {
	@Autowired
	private BrandRepository brandRepository;
	@Autowired
	private CatagoryRepository catagoryRepository;

	@Override
	public void saveBrand(Brand brand) {
		brandRepository.save(brand);
	}

	@Override
	public List<Brand> getBrandList() {
		return brandRepository.findAll();
	}

	@Override
	public void assignBrand(int catagoryId, int brandId) {
		Brand brand = brandRepository.findById(brandId).get();
		Catagory catagory = catagoryRepository.findById(catagoryId).get();
		brand.getCatagories().add(catagory);
		catagory.getBrands().add(brand);
		catagoryRepository.save(catagory);
		brandRepository.save(brand);
	}

	@Override
	public List<Shirt> getAllShirts(int brandId) {
		Brand brand = brandRepository.findById(brandId).get();
		List<Shirt> getShirtList = brand.getShirts();
		return getShirtList;
	}

	@Override
	public List<Jacket> getAlljackets(int brandId) {
		Brand brand = brandRepository.findById(brandId).get();
		List<Jacket> getJacketList = brand.getJackets();
		return getJacketList;
	}

	@Override
	public String getBrandName(int brandId) {
		Brand brand = brandRepository.findById(brandId).get();
		return brand.getBrandName();
	}

}
