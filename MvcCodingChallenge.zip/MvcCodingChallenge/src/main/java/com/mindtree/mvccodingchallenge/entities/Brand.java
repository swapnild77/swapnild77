/**
 * 
 */
package com.mindtree.mvccodingchallenge.entities;

import java.util.*;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author M1057685
 *
 */
@Entity
public class Brand {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int brandId;
	@NotNull
	private String brandName;
	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
	@JsonIgnore
	private List<Catagory> catagories;
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "brand")
	private List<Shirt> shirts;
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "brand")
	private List<Jacket> jackets;

	/**
	 * @param brandId
	 * @param brandName
	 * @param catagories
	 * @param shirts
	 * @param jackets
	 */
	public Brand(int brandId, @NotNull String brandName, List<Catagory> catagories, List<Shirt> shirts,
			List<Jacket> jackets) {
		this.brandId = brandId;
		this.brandName = brandName;
		this.catagories = catagories;
		this.shirts = shirts;
		this.jackets = jackets;
	}

	/**
	 * 
	 */
	public Brand() {
	}

	/**
	 * @return the brandId
	 */
	public int getBrandId() {
		return brandId;
	}

	/**
	 * @param brandId the brandId to set
	 */
	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}

	/**
	 * @return the brandName
	 */
	public String getBrandName() {
		return brandName;
	}

	/**
	 * @param brandName the brandName to set
	 */
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	/**
	 * @return the catagories
	 */
	public List<Catagory> getCatagories() {
		return catagories;
	}

	/**
	 * @param catagories the catagories to set
	 */
	public void setCatagories(List<Catagory> catagories) {
		this.catagories = catagories;
	}

	/**
	 * @return the shirts
	 */
	public List<Shirt> getShirts() {
		return shirts;
	}

	/**
	 * @param shirts the shirts to set
	 */
	public void setShirts(List<Shirt> shirts) {
		this.shirts = shirts;
	}

	/**
	 * @return the jackets
	 */
	public List<Jacket> getJackets() {
		return jackets;
	}

	/**
	 * @param jackets the jackets to set
	 */
	public void setJackets(List<Jacket> jackets) {
		this.jackets = jackets;
	}

}
