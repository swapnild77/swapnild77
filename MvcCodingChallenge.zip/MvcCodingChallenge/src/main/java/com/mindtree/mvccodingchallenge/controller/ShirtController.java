/**
 * 
 */
package com.mindtree.mvccodingchallenge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mindtree.mvccodingchallenge.entities.Brand;
import com.mindtree.mvccodingchallenge.entities.Shirt;
import com.mindtree.mvccodingchallenge.service.BrandService;
import com.mindtree.mvccodingchallenge.service.ShirtService;

/**
 * @author M1057685
 *
 */
@Controller
public class ShirtController {
	@Autowired
	private BrandService brandService;
	@Autowired
	private ShirtService shirtService;
	@RequestMapping(value = "/viewShirtPage")
	public String viewShirtPage(Model model) {
		List<Brand> getBrandList = brandService.getBrandList();
		model.addAttribute("getBrandList", getBrandList);
		Shirt shirt = new Shirt();
		model.addAttribute("shirt", shirt);
		return "viewShirtPage";
	}
	
	@RequestMapping(value = "/saveShirt")
	public String saveShirt(@ModelAttribute(value = "shirt") Shirt shirt)
	{
		shirtService.addShirt(shirt);
		return "redirect:/";
	}
}
