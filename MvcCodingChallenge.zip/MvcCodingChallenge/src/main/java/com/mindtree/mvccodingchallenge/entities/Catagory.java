/**
 * 
 */
package com.mindtree.mvccodingchallenge.entities;

import java.util.*;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.validation.constraints.NotNull;

/**
 * @author M1057685
 *
 */
@Entity
public class Catagory {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int catagoryId;
	@NotNull
	private String catagoryName;
	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST, mappedBy = "catagories")
	private List<Brand> brands;

	/**
	 * @param catagoryId
	 * @param catagoryName
	 * @param brands
	 */
	public Catagory(int catagoryId, @NotNull String catagoryName, List<Brand> brands) {
		this.catagoryId = catagoryId;
		this.catagoryName = catagoryName;
		this.brands = brands;
	}

	/**
	 * 
	 */
	public Catagory() {
	}

	/**
	 * @return the catagoryId
	 */
	public int getCatagoryId() {
		return catagoryId;
	}

	/**
	 * @param catagoryId the catagoryId to set
	 */
	public void setCatagoryId(int catagoryId) {
		this.catagoryId = catagoryId;
	}

	/**
	 * @return the catagoryName
	 */
	public String getCatagoryName() {
		return catagoryName;
	}

	/**
	 * @param catagoryName the catagoryName to set
	 */
	public void setCatagoryName(String catagoryName) {
		this.catagoryName = catagoryName;
	}

	/**
	 * @return the brands
	 */
	public List<Brand> getBrands() {
		return brands;
	}

	/**
	 * @param brands the brands to set
	 */
	public void setBrands(List<Brand> brands) {
		this.brands = brands;
	}

}
