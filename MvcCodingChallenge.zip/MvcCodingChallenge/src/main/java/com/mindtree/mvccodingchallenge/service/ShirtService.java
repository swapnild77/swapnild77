/**
 * 
 */
package com.mindtree.mvccodingchallenge.service;

import org.springframework.stereotype.Service;

import com.mindtree.mvccodingchallenge.entities.Shirt;

/**
 * @author M1057685
 *
 */
@Service
public interface ShirtService {

	/**
	 * @param shirt
	 */
	void addShirt(Shirt shirt);

}
