/**
 * 
 */
package com.mindtree.mvccodingchallenge.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.mvccodingchallenge.entities.Brand;
import com.mindtree.mvccodingchallenge.entities.Shirt;
import com.mindtree.mvccodingchallenge.repository.BrandRepository;
import com.mindtree.mvccodingchallenge.repository.ShirtRepository;
import com.mindtree.mvccodingchallenge.service.ShirtService;

/**
 * @author M1057685
 *
 */
@Service
public class ShitServiceImpl implements ShirtService {
	@Autowired
	private ShirtRepository shirtRepository;
	@Autowired
	private BrandRepository brandRepository;

	@Override
	public void addShirt(Shirt shirt) {
		Brand brand = brandRepository.findById(shirt.getBrand().getBrandId()).get();
		shirt.setBrand(brand);
		shirtRepository.save(shirt);
	}

}
