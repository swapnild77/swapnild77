package com.mindtree.mvccodingchallenge.service;

import org.springframework.stereotype.Service;

import com.mindtree.mvccodingchallenge.entities.Jacket;

/**
 * @author M1057685
 *
 */
@Service
public interface JacketService {

	/**
	 * @param jacket
	 */
	void addJacket(Jacket jacket);

}
