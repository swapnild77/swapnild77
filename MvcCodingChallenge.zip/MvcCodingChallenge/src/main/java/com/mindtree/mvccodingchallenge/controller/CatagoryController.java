/**
 * 
 */
package com.mindtree.mvccodingchallenge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mindtree.mvccodingchallenge.entities.Brand;
import com.mindtree.mvccodingchallenge.entities.Catagory;
import com.mindtree.mvccodingchallenge.service.CatagoryService;

/**
 * @author M1057685
 *
 */
@Controller
public class CatagoryController {
	@Autowired
	private CatagoryService catagoryService;

	@RequestMapping(value = "/")
	public String indexPage() {
		return "index";
	}

	@RequestMapping(value = "/viewCatagoryPage")
	public String viewCatagoryPage(Model model) {
		Catagory catagory = new Catagory();
		model.addAttribute("catagory", catagory);
		return "catagoryPage";
	}

	@RequestMapping(value = "/saveCatagory")
	public String saveCatagory(@ModelAttribute(value = "catagory") Catagory catagory) {
		catagoryService.addCatagory(catagory);
		return "redirect:/";
	}

	@RequestMapping(value = "/displayPage")
	public String displayPage(Model model) {
		List<Catagory> getCatagoryList = catagoryService.getCatagoryList();
		model.addAttribute("getCatagoryList", getCatagoryList);
		return "displayPage";
	}

	@RequestMapping(value = "/details/{catagoryId}")
	public String brandDetailsPage(@PathVariable int catagoryId, Model model) {
		List<Brand> getAllBrandDetails = catagoryService.getAllBrands(catagoryId);
		model.addAttribute("getAllBrandDetails", getAllBrandDetails);
		return "brandDetailsPage";
	}
}
