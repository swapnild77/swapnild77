/**
 * 
 */
package com.mindtree.mvccodingchallenge.entities;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author M1057685
 *
 */
@Entity
public class Shirt {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int shirtId;
	@NotNull
	private String shirtName;
	@NotNull
	private double discount;
	@NotNull
	private double price;
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private Brand brand;

	/**
	 * @param shirtId
	 * @param shirtName
	 * @param discount
	 * @param price
	 * @param brand
	 */
	public Shirt(int shirtId, @NotNull String shirtName, @NotNull double discount, @NotNull double price, Brand brand) {
		this.shirtId = shirtId;
		this.shirtName = shirtName;
		this.discount = discount;
		this.price = price;
		this.brand = brand;
	}

	/**
	 * 
	 */
	public Shirt() {
	}

	/**
	 * @return the shirtId
	 */
	public int getShirtId() {
		return shirtId;
	}

	/**
	 * @param shirtId the shirtId to set
	 */
	public void setShirtId(int shirtId) {
		this.shirtId = shirtId;
	}

	/**
	 * @return the shirtName
	 */
	public String getShirtName() {
		return shirtName;
	}

	/**
	 * @param shirtName the shirtName to set
	 */
	public void setShirtName(String shirtName) {
		this.shirtName = shirtName;
	}

	/**
	 * @return the discount
	 */
	public double getDiscount() {
		return discount;
	}

	/**
	 * @param discount the discount to set
	 */
	public void setDiscount(double discount) {
		this.discount = discount;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/**
	 * @return the brand
	 */
	public Brand getBrand() {
		return brand;
	}

	/**
	 * @param brand the brand to set
	 */
	public void setBrand(Brand brand) {
		this.brand = brand;
	}

}
