/**
 * 
 */
package com.mindtree.mvccodingchallenge.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.mvccodingchallenge.entities.Brand;
import com.mindtree.mvccodingchallenge.entities.Jacket;
import com.mindtree.mvccodingchallenge.entities.Shirt;

/**
 * @author M1057685
 *
 */
@Service
public interface BrandService {

	/**
	 * @param brand
	 */
	void saveBrand(Brand brand);

	/**
	 * @return
	 */
	List<Brand> getBrandList();

	/**
	 * @param catagoryId
	 * @param brandId
	 */
	void assignBrand(int catagoryId, int brandId);

	/**
	 * @param brandId
	 * @return
	 */
	List<Shirt> getAllShirts(int brandId);

	/**
	 * @param brandId
	 * @return
	 */
	List<Jacket> getAlljackets(int brandId);

	/**
	 * @param brandId
	 * @return
	 */
	String getBrandName(int brandId);

}
