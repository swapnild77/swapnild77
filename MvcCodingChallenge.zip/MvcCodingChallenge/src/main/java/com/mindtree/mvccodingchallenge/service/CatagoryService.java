/**
 * 
 */
package com.mindtree.mvccodingchallenge.service;

import org.springframework.stereotype.Service;
import java.util.*;

import com.mindtree.mvccodingchallenge.entities.Brand;
import com.mindtree.mvccodingchallenge.entities.Catagory;

/**
 * @author M1057685
 *
 */
@Service
public interface CatagoryService {

	/**
	 * @param catagory
	 */
	void addCatagory(Catagory catagory);

	/**
	 * @return
	 */
	List<Catagory> getCatagoryList();

	/**
	 * @param catagoryId
	 * @return
	 */
	List<Brand> getAllBrands(int catagoryId);

}
