/**
 * 
 */
package com.mindtree.mvccodingchallenge.entities;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author M1057685
 *
 */
@Entity
public class Jacket {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int jacketId;
	@NotNull
	private String jacketColor;
	@NotNull
	private double jacketDiscount;
	@NotNull
	private double jacketPrice;
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private Brand brand;

	/**
	 * @param jacketId
	 * @param jacketColor
	 * @param jacketDiscount
	 * @param jacketPrice
	 * @param brand
	 */
	public Jacket(int jacketId, @NotNull String jacketColor, @NotNull double jacketDiscount,
			@NotNull double jacketPrice, Brand brand) {
		this.jacketId = jacketId;
		this.jacketColor = jacketColor;
		this.jacketDiscount = jacketDiscount;
		this.jacketPrice = jacketPrice;
		this.brand = brand;
	}

	/**
	 * 
	 */
	public Jacket() {
	}

	/**
	 * @return the jacketId
	 */
	public int getJacketId() {
		return jacketId;
	}

	/**
	 * @param jacketId the jacketId to set
	 */
	public void setJacketId(int jacketId) {
		this.jacketId = jacketId;
	}

	/**
	 * @return the jacketColor
	 */
	public String getJacketColor() {
		return jacketColor;
	}

	/**
	 * @param jacketColor the jacketColor to set
	 */
	public void setJacketColor(String jacketColor) {
		this.jacketColor = jacketColor;
	}

	/**
	 * @return the jacketDiscount
	 */
	public double getJacketDiscount() {
		return jacketDiscount;
	}

	/**
	 * @param jacketDiscount the jacketDiscount to set
	 */
	public void setJacketDiscount(double jacketDiscount) {
		this.jacketDiscount = jacketDiscount;
	}

	/**
	 * @return the jacketPrice
	 */
	public double getJacketPrice() {
		return jacketPrice;
	}

	/**
	 * @param jacketPrice the jacketPrice to set
	 */
	public void setJacketPrice(double jacketPrice) {
		this.jacketPrice = jacketPrice;
	}

	/**
	 * @return the brand
	 */
	public Brand getBrand() {
		return brand;
	}

	/**
	 * @param brand the brand to set
	 */
	public void setBrand(Brand brand) {
		this.brand = brand;
	}

}
