/**
 * 
 */
package com.mindtree.mvccodingchallenge.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.mvccodingchallenge.entities.Brand;
import com.mindtree.mvccodingchallenge.entities.Jacket;
import com.mindtree.mvccodingchallenge.repository.BrandRepository;
import com.mindtree.mvccodingchallenge.repository.JacketRepository;
import com.mindtree.mvccodingchallenge.service.JacketService;

/**
 * @author M1057685
 *
 */
@Service
public class JacketServiceImpl implements JacketService {
	@Autowired
	private BrandRepository brandRepository;
	@Autowired
	private JacketRepository jacketRepository;

	@Override
	public void addJacket(Jacket jacket) {
		Brand brand = brandRepository.findById(jacket.getBrand().getBrandId()).get();
		jacket.setBrand(brand);
		jacketRepository.save(jacket);
	}

}
