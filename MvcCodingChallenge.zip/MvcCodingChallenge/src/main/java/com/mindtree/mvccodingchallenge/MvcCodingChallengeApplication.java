package com.mindtree.mvccodingchallenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcCodingChallengeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcCodingChallengeApplication.class, args);
	}

}
