/**
 * 
 */
package com.mindtree.mvccodingchallenge.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.mvccodingchallenge.entities.Brand;
import com.mindtree.mvccodingchallenge.entities.Catagory;
import com.mindtree.mvccodingchallenge.repository.CatagoryRepository;
import com.mindtree.mvccodingchallenge.service.CatagoryService;

/**
 * @author M1057685
 *
 */
@Service
public class CatagoryServiceImpl implements CatagoryService {
	@Autowired
	private CatagoryRepository catagoryRepository;

	@Override
	public void addCatagory(Catagory catagory) {
		catagoryRepository.save(catagory);
	}

	@Override
	public List<Catagory> getCatagoryList() {
		return catagoryRepository.findAll();
	}

	@Override
	public List<Brand> getAllBrands(int catagoryId) {
		Catagory catagory = catagoryRepository.findById(catagoryId).get();
		List<Brand> getBrands = catagory.getBrands();
		return getBrands;
	}

}
